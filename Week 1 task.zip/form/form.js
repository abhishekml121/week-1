var textarea = document.querySelector('.textarea textarea');
var form = document.getElementById('form');
var phone = document.getElementById('phone_no');
var submit = document.getElementById('submit_btn');

function animation(event) {
    //console.log(event);
    var span = event.srcElement.nextElementSibling;
    if ((event.target.value.trim().length) >= 1) {
        if (event.target.type === 'textarea') {
            textarea.style = "font-size: 18px;";
            span.style = "top: -25px;font-size:17px;";
        } else {
            span.style = "top: -25px; left: 0px;font-size: 17px;opacity: 1;";
        }
        if (event.srcElement.name == 'phone') {
            phoneValidation(phone.value, event);
        }

    } else {
        if (event.target.type === 'textarea') {
            textarea.style = "font-size: 18px;";
            span.style = "font-size:16px;top: -10px;";

        } else {

            span.style = "top: -10px;font-size: 19px;";
        }
        // console.log(event.target.onfocus == true, 5555);
    }
}
/*
     Accept only number [0-9], if number is not found then bottom border turn into color red
     and disable the submit button
*/
function phoneValidation(mo_number, e) {
    var accept_values = /^[0-9]*$/;
    if ((mo_number.match(accept_values))) {
        e.target.style = "border-bottom:1px solid green;";
        submit.disabled = false;
    } else {
        e.target.style = "border-bottom:1px solid red;";
        submit.disabled = true;
    }
}

// Capture the keyboard event on input fields of form
form.addEventListener('keyup', animation, false);